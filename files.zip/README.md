# Secure VPC Build and Web Server Deployment on AWS

A production-style AWS network built from scratch — custom VPC, multi-AZ public/private subnets, routing, NAT/IGW, security groups, and a working Apache + PHP web server on EC2, reachable from the public internet.

## Overview

| | |
|---|---|
| **Goal** | Build a two-AZ VPC network and deploy a web server that's publicly reachable over HTTP |
| **Primary AWS Services** | VPC, Subnets, Route Tables, Internet Gateway, NAT Gateway, Security Groups, EC2 |
| **Compute** | EC2 `t3.micro`, Amazon Linux 2023, Apache + PHP-FPM |

## Architecture

**VPC:** `10.0.0.0/16` (Lab VPC)

| Subnet | CIDR | Type |
|---|---|---|
| Public Subnet 1 | `10.0.0.0/24` | Public (routed to IGW) |
| Private Subnet 1 | `10.0.1.0/24` | Private (routed to NAT) |
| Public Subnet 2 | `10.0.2.0/24` | Public — **web server lives here** |
| Private Subnet 2 | `10.0.3.0/24` | Private (routed to NAT) |

- **Internet Gateway (IGW):** provides inbound/outbound internet access for public subnets
- **NAT Gateway:** lets private-subnet instances reach the internet outbound without being publicly reachable
- **Route Tables:** a Public Route Table (`0.0.0.0/0 → IGW`) associated with both public subnets, and a Private Route Table (`0.0.0.0/0 → NAT`) associated with both private subnets

## Security

**Security Group — Web Security Group**

![Security group inbound rules](images/security-group-inbound-rules.png)

- Inbound: HTTP (80) from `0.0.0.0/0`, plus SSH (22) scoped to the EC2 Instance Connect service range (`18.206.107.24/29`) rather than the whole internet
- Outbound: all traffic allowed

![Security group outbound rules](images/security-group-outbound-rules.png)

**Network ACL** (subnet-level, stateless) — left at the default allow-all, confirmed during troubleshooting:

![NACL inbound rules](images/nacl-inbound-rules.png)
![NACL outbound rules](images/nacl-outbound-rules.png)

## Deployment

Launched into **Public Subnet 2** with a public IP auto-assigned. Bootstrapped via EC2 user data to install Apache/PHP and deploy the sample app:

```bash
#!/bin/bash
yum install -y httpd php
wget https://aws-tc-largeobjects.s3.us-west-2.amazonaws.com/CUR-TF-100-RESTRT-1/267-lab-NF-build-vpc-web-server/s3/lab-app.zip
unzip lab-app.zip -d /var/www/html/
chkconfig httpd on
service httpd start
```

> **Note:** the original lab script (`mysql` package, AL2) needed adapting for **Amazon Linux 2023** — see Troubleshooting below.

## Validation

Instance reached **3/3 status checks passed** with a stable public IP:

![Instance status checks](images/instance-status-checks.png)
![Instance details panel](images/instance-details-panel.png)

Server reachability was confirmed independently of any single browser, using AWS CloudShell (runs outside the VPC and outside any local network):

```bash
$ curl -I http://13.222.55.198/test.php
HTTP/1.1 200 OK
Date: Tue, 04 Aug 2026 19:22:03 GMT
Server: Apache/2.4.68 (Amazon Linux)
X-Powered-By: PHP/8.5.8
Content-Type: text/html; charset=UTF-8
```

A `200 OK` with `X-Powered-By: PHP` proves the full chain — routing, security group, Apache, and PHP-FPM — is working end to end.

## Troubleshooting & Lessons Learned

Real issues hit during the build, and how each was diagnosed and resolved:

1. **User data script silently failed.** Copying the bootstrap script out of a Word document introduced Windows-style line endings, which collapsed the whole script into one unrunnable line. *Fix:* paste user data as plain text, or run the commands manually over EC2 Instance Connect.
2. **`yum install mysql` failed.** Amazon Linux 2023 dropped the standalone `mysql` package in favor of MariaDB-based ones. *Fix:* dropped `mysql` from the install (not required for this app) — install `php-mysqlnd` instead if a DB connection is ever needed.
3. **PHP files served blank.** AL2023 doesn't wire `php` into Apache automatically the way AL2 did. *Fix:* installed `php-fpm` and added an explicit `SetHandler` proxy block in `/etc/httpd/conf.d/php-fpm.conf` pointing at the PHP-FPM socket, then restarted both services.
4. **Site unreachable from the browser after everything else checked out.** Systematically ruled out the security group, NACL, route table, subnet placement, host firewall, and the Apache listener itself — all correct. Root cause turned out to be the *browser* silently upgrading `http://` to `https://` (HTTPS-only mode), which timed out since only port 80 was open. Confirmed via `curl` from AWS CloudShell, bypassing the browser entirely.

**Key takeaway:** when a deployed service is unreachable, verify each layer independently (server logs → local curl → external curl from outside the network → client-side settings) rather than assuming the problem is in the AWS configuration.

## Skills Demonstrated

- VPC design and IPv4 subnetting (CIDR planning)
- Public vs. private subnet isolation and routing
- IGW vs. NAT Gateway use cases
- Security Groups (stateful) vs. Network ACLs (stateless) as layered firewalls
- EC2 launch configuration and user-data bootstrapping
- Linux service management or systemd on Amazon Linux 2023
- Systematic network troubleshooting across the AWS stack and the client side
